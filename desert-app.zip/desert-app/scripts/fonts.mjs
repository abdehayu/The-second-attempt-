// Copies DM Sans, Playfair Display and Amiri (latin + arabic) into www/fonts for offline use.
import fs from "node:fs";
import path from "node:path";

const fams = {
  "dm-sans": [400, 500, 600, 700],
  "playfair-display": [500, 600, 700, 800],
  "amiri": [400, 700],
};
const out = path.resolve("www/fonts");
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, "files"), { recursive: true });

let css = "";
for (const [name, weights] of Object.entries(fams)) {
  const base = path.resolve("node_modules/@fontsource", name);
  if (!fs.existsSync(base)) throw new Error(`Missing ${base}. Run "npm install" first.`);
  for (const w of weights) css += fs.readFileSync(path.join(base, `${w}.css`), "utf8") + "\n";
  for (const f of fs.readdirSync(path.join(base, "files"))) {
    if (/-(latin|arabic)(-ext)?-/.test(f) && f.endsWith(".woff2")) {
      fs.copyFileSync(path.join(base, "files", f), path.join(out, "files", f));
    }
  }
}
fs.writeFileSync(path.join(out, "fonts.css"), css);
console.log("Fonts copied to www/fonts");
