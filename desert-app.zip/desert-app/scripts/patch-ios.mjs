// Sets the iOS audio session to "playback" so sound plays even with the silent switch on.
import fs from "node:fs";

const file = "ios/App/App/AppDelegate.swift";
let s = fs.readFileSync(file, "utf8");
if (s.includes("AVAudioSession")) {
  console.log("AppDelegate already patched");
  process.exit(0);
}
if (!s.includes("import AVFoundation")) s = s.replace("import UIKit", "import UIKit\nimport AVFoundation");
const re = /(didFinishLaunchingWithOptions[^{]*\{)/;
if (!re.test(s)) throw new Error("Could not find didFinishLaunchingWithOptions; patch AppDelegate.swift manually (see README).");
s = s.replace(re, "$1\n        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)");
fs.writeFileSync(file, s);
console.log("AppDelegate patched");
